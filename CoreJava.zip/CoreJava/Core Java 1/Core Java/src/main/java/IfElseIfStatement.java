public class IfElseIfStatement {
    public static void main(String[] args) {
        String city="Hyderabad";
        if(city=="delhi") {
            System.out.println("city delhi");
        }
       else if(city=="noida") {
            System.out.println("city noida");
        }
        else {
            System.out.println(city);
        }
    }
}
