package org.example.learning.thiskeyword;

public class Test1 {
    //program with thiskeyword
    int id;
    String name;
    Test1(int id,String name){
       this.id=id;
       this.name=name;
    }
    public void display(){
        System.out.println(id+" "+name);
    }

    public static void main(String[] args) {
        Test1 t=new Test1(101,"sweety");
        Test1 t1=new Test1(102,"vahini");
        t1.display();
        t.display();
    }
}


