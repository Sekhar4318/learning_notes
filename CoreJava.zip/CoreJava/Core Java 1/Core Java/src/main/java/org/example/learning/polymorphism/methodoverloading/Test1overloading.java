package org.example.learning.polymorphism.methodoverloading;
//Method Overloading: changing no. of arguments program
class Adder1 {
    static int add(int a, int b) //if we take method as static no need to create an instace
    {
        return a + b;
    }

    static int add(int a, int b, int c) {
        return a + b + c;
    }
}

public class Test1overloading {
    public static void main(String[] args) {
        System.out.println(Adder1.add(11,11));
        System.out.println(Adder1.add(11,11,11));
    }
}
