package org.example.learning.loopstatments;

public class ForEachLoop {
    public static void main(String[] args) {
        String[] names={"sony","sweety","vahini","shivani","sharath"};
        System.out.println("The names are");
        for (String name:names
             )
        {
           System.out.println(name);
        }
    }
}
