package org.example.learning.strings;

public class ImmutableStringExp {
    public static void main(String[] args) {
        String s1="vahini";
        s1.concat("nallagoni");//concat() method appends the string at the end
        System.out.println(s1);//will print vahini because strings are immutable objects
        //But if we explicitly assign it to the reference variable, it will refer to "vahini nallagoni" object.
        // s1=s1.concat("nallagoni");
        //System.out.println(s1);
    }
}
