package org.example.learning.decisionmakingstatements;

public class NestedIfStament {
    public static void main(String[] args) {
        String address = "Delhi,India";
        if (address.endsWith("India")) {
            if (address.contains("meeruit")) {
                System.out.println("your city is meeruit");
            } else if (address.contains("noida")) {
                System.out.println("your city is noida");

            } else {
                System.out.println(address.split(",")[0]);
            }
        } else {
            System.out.println("you are not living in india");

        }
    }
}
