package org.example.learning.encapsulation;

public class Test {
    public static void main(String[] args) {
        Student st=new Student();
        st.setId(25);
        st.setName("vahini");
        st.setEmail("nallagoni@gmail");
        st.setAcnum(2562542164324L);
        System.out.println(st.getId()+" "+ st.getAcnum()+" "+st.getEmail()+" "+st.getName());
    }
}
