package org.example.learning.statickeyword;

public class Student1 {
    int id;
    String name;
    static String college="MLR"; //static varaible
    Student1(int i,String n){
        id=i;
        name=n;

    }
    void display(){
        System.out.println(id+" "+name+" "+college);
    }

    public static void main(String[] args) {
        Student1 s1=new Student1(101,"sweety");
        Student1 s2=new Student1(102,"sony");
        s1.display();
        //we can change the college of all objects by the single line of code
        //Student1.college="SVS";
        s2.display();
        System.out.println("Static varaible program..");


    }
}
