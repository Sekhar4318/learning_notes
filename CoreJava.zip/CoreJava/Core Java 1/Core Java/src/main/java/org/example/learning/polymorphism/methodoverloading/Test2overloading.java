package org.example.learning.polymorphism.methodoverloading;
//Method Overloading: changing data type of arguments program
class Adder {
    static int add1(int a, int b) //if we take method as static no need to create an instace
    {
        return a + b;
    }

    static double add1(double a, double b) {
        return a + b;
    }
}
public class Test2overloading {
    public static void main(String[] args) {
        System.out.println(Adder.add1(11,11));
        System.out.println(Adder.add1(12.0,12.2));
    }
}

