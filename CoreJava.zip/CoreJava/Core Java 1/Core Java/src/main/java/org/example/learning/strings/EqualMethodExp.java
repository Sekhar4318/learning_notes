package org.example.learning.strings;

public class EqualMethodExp {
    public static void main(String[] args) {
        String s1="java";
        String s2=new String("Java");
        String s3="java";
        String s4="python";
        System.out.println(s1.equals(s2));
        System.out.println(s1.equals(s3));
        System.out.println(s1.equalsIgnoreCase(s2));
        System.out.println(s2.equals(s4));

    }
}
