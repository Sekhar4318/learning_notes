package org.example.learning.abstractmethod;

abstract class Demo {
    abstract void display();
}

public class MyClass extends Demo {
    void display() {
        System.out.println("Abstract Mathod..");
    }

    public static void main(String[] args) {
        Demo d=new MyClass();
        d.display();

    }
}
