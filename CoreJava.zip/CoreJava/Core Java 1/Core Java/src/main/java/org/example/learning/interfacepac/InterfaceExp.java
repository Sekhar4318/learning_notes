package org.example.learning.interfacepac;

interface Animal{
    void eat();
}
class Dog implements Animal{
   public void eat(){
        System.out.println("eating....");
    }
}
public class InterfaceExp {
    public static void main(String[] args) {
        Dog d=new Dog();
        d.eat();
    }
}
