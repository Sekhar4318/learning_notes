package org.example.learning.execptionhandling;

public class TestExp {
    public static void main(String[] args) {
        try{
            int data=10/0;
        }
        catch (ArithmeticException e){
            System.out.println(e);
            System.out.println("rest of the code...");
        }
    }
}
