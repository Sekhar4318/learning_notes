package org.example.learning.polymorphism.methodoverriding;

class Vechile{
    void run(){
        System.out.println("riding....");
    }
}
class Bike extends Vechile{
    void run(){
        System.out.println("chasing...");
    }
}
public class MethodOverridingexp {
    public static void main(String[] args) {
        Bike b=new Bike();
        b.run();
    }
}
