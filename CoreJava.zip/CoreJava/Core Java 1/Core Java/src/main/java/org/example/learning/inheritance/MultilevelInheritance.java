package org.example.learning.inheritance;

class Animal1{
    void eat(){
        System.out.println("eating...");
    }
}
class Dog1 extends Animal1{
    void barking(){
        System.out.println("BARKING....");
    }
}
class BabyDog extends Dog1{
    void sleep(){
        System.out.println("sleeping....");
    }
}

public class MultilevelInheritance {
    public static void main(String[] args) {
        Dog1 d = new Dog1();
        d.barking();
        d.eat();

    }
}

//Consider a scenario where A, B, and C are three classes. The C class inherits A and B classes. If A and B classes have the same method and you call it from child class object, there will be ambiguity to call the method of A or B class.
//
//Since compile-time errors are better than runtime errors, Java renders compile-time error if you inherit 2 classes. So whether you have same method or different, there will be compile time error.
