package org.example.learning.arrays;

public class SingleDimensionalArray4 {
    public static void main(String[] args) {
        int a[]=new int[5];
        a[0]=13;
        a[1]=12;
        a[2]=14;
        a[3]=16;
        a[4]=5;
            for(int i=0;i<a.length;i++)
            System.out.println(a[i]);
    }
}
