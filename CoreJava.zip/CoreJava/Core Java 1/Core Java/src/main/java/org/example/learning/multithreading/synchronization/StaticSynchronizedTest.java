package org.example.learning.multithreading.synchronization;


class Table2
{
   static synchronized void printTable(int n)
    {
            for(int i=1;i<=5;i++){
                System.out.println(n*i);
                try{
                    Thread.sleep(400);
                }catch(Exception e){System.out.println(e);}
            }
        }

}

class MyThread5 extends Thread{
    Table2 t;
    MyThread5(Table2 t){
        this.t=t;
    }
    public void run(){
        t.printTable(2);
    }

}
class MyThread6 extends Thread{
    Table2 t;
    MyThread6(Table2 t){
        this.t=t;
    }
    public void run(){
        t.printTable(10);
    }
}

public class StaticSynchronizedTest{
    public static void main(String args[]){
        Table2 obj2 = new Table2();//only one object
        MyThread5 t5=new MyThread5(obj2);
        MyThread6 t6=new MyThread6(obj2);
        t5.start();
        t6.start();
    }
}
