package org.example.learning.execptionhandling;

public class ThrowkeywordExp {
    public static void validate(int age){
        if(age<18){
            throw new ArithmeticException("person not eligible for vote");

        }
        else {
            System.out.println("right to vote");
        }

    }

    public static void main(String[] args) {
        validate(19);
    }

}
