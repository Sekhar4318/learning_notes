package org.example.learning.strings;

public class EqualsOperatorMethodExp {
    public static void main(String[] args) {
        String s1 = "java";
        String s2 = new String("Java");
        String s3 = "java";
        System.out.println(s1==s2);//false(because s2 refers to instance created in nonpool)
        System.out.println(s1==s3);//true (because both refer to same instance)

    }
}
