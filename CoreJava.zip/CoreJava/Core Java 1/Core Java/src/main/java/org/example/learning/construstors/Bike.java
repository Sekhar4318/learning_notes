package org.example.learning.construstors;

public class Bike {
    Bike(){
        System.out.println("default constructor");
    }

    public static void main(String[] args) {
        Bike b=new Bike();
    }
}
