package org.example.learning.construstors;

public class Student {
    int id;
    String name;
    Student(int i,String n){
        id=i;
       name=n;
        System.out.println("parametarized constructor");
    }
    void display(){
        System.out.println(id+" "+name);
    }

    public static void main(String[] args) {
        Student s=new Student(101,"vahini");
        s.display();
    }
}
