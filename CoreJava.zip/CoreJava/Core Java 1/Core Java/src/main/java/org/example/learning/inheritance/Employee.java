package org.example.learning.inheritance;

//Inheritance program
public class Employee {
    float salary = 40000.0F;
}

    class Programmer extends Employee{
        int bonus=20000;

        public static void main(String[] args) {
            Programmer p=new Programmer();
            System.out.println("Employee salary is"+p.salary);
            System.out.println("programmer bonus is "+p.bonus);

        }
    }

