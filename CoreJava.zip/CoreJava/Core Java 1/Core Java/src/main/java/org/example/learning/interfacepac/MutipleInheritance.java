package org.example.learning.interfacepac;

interface Printable{
    void print();
}
interface Showable{
    void show();
}
class A implements Printable,Showable {

    public void print() {
        System.out.println("printing...");
    }

    public void show() {
        System.out.println("showing...");
    }
}
public class MutipleInheritance {
    public static void main(String[] args) {
        A a=new A();
        a.print();
        a.show();
    }
}
