package org.example.learning.execptionhandling;


import java.io.IOException;

class ThrowsKeywordEXp {
    void m() throws IOException {
        throw new IOException("device error");//checked exception
    }

    void n() throws IOException {
        m();
    }

    void p() {
        try {
            n();
        } catch (Exception e) {
            System.out.println("exception handled");
        }
    }

    public static void main(String args[]) {
        ThrowsKeywordEXp obj = new ThrowsKeywordEXp();
        obj.p();
        System.out.println("normal flow...");
    }
    }
