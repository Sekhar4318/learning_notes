package org.example.learning.superkeyword;

//super is used to refer immediate parent class instance variable program
       // We can use super keyword to access the data member or field of parent class. It is used if parent class and child class have same fields.
class Bird{
    String colour="white";


}
class Parrot extends Bird{
    String colour="Green";
    void display(){
        System.out.println(colour);
        System.out.println(super.colour);
    }
}
public class SuperTest1 {
    public static void main(String[] args) {
        Parrot p=new Parrot();
        p.display();
    }
}
