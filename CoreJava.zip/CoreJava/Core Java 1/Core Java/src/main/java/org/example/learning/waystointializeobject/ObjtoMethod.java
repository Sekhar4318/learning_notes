package org.example.learning.waystointializeobject;

class Test1 {
    int id;
    String name;
 void insertData(int i,String n){
     name=n;
     id=i;
 }
 void display(){
     System.out.println(id+" "+name);
 }

}

public class ObjtoMethod {
    public static void main(String[] args) {
        Test1 t1=new Test1();
        t1.insertData(101,"sharu");
        t1.display();

    }
}
