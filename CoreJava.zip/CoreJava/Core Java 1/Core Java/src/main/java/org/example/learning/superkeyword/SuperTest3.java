package org.example.learning.superkeyword;
//super is used to invoke parent class constructor program
       // The super keyword can also be used to invoke the parent class constructor.
class Animal1{
    Animal1(){
        System.out.println("eating...");
    }

    Animal1(int a){
        System.out.println(a);
    }
    public void aniamleat(){

    }
}
class Dog1 extends  Animal1 {
    Dog1() {
        super(20);
        System.out.println("eating bicket...");
    }

}
public class SuperTest3 {
    public static void main(String[] args) {
        Dog1 d1=new Dog1();
    }
}

