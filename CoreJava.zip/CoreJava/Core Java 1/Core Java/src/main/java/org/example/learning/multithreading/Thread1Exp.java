package org.example.learning.multithreading;
// Java Thread Example by extending Thread class

public class Thread1Exp extends Thread{
    public void run(){
        System.out.println("threading is running...");
    }

    public static void main(String[] args) {
        Thread1Exp t1=new Thread1Exp();
        t1.start();
    }
}
