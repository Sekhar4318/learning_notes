package org.example.learning.construstors;

public class DemoStudent {
    int id;
    String name;
    String address;
    DemoStudent(int i,String n){
        id=i;
        name=n;
    }
    DemoStudent(int i,String n,String ad){
        id=i;
        name=n;
        address=ad;
        System.out.println("Constructor overloading...");
    }
    public void display(){
        System.out.println(id+" "+name+" "+address);
    }

    public static void main(String[] args) {
        DemoStudent d=new DemoStudent(101,"shivani");
        DemoStudent d1=new DemoStudent(102,"sharu","karnataka");
        d.display();
        d1.display();
    }

}
