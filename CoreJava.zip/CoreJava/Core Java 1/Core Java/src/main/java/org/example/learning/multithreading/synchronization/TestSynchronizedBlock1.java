package org.example.learning.multithreading.synchronization;

class Table1
        {
        void printTable(int n)
        {
          synchronized(this){//synchronized block
        for(int i=1;i<=5;i++){
              System.out.println(n*i);
        try{
            Thread.sleep(400);
        }catch(Exception e){System.out.println(e);}
        }
        }
        }//end of the method
        }

class MyThread3 extends Thread{
    Table1 t;
    MyThread3(Table1 t){
        this.t=t;
    }
    public void run(){
        t.printTable(5);
    }

}
class MyThread4 extends Thread{
    Table1 t;
    MyThread4(Table1 t){
        this.t=t;
    }
    public void run(){
        t.printTable(100);
    }
}

public class TestSynchronizedBlock1{
    public static void main(String args[]){
        Table1 obj1 = new Table1();//only one object
        MyThread3 t3=new MyThread3(obj1);
        MyThread4 t4=new MyThread4(obj1);
        t3.start();
        t4.start();
    }
}