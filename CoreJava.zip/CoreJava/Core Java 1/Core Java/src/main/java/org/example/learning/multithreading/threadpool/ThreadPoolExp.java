package org.example.learning.multithreading.threadpool;

import javax.annotation.processing.Processor;

public class ThreadPoolExp implements  Runnable {
    private String message;

    public ThreadPoolExp(String s) {
        this.message = s;
    }

    public void run() {
        System.out.println(Thread.currentThread().getName() + "(start)message is:" + message);
        processmessage();
        System.out.println(Thread.currentThread().getName() + "(end)");

    }

    private void processmessage() {
        try {
            Thread.sleep(200);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
    }
}
