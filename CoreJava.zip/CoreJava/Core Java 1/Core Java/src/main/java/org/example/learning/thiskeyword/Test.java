package org.example.learning.thiskeyword;

public class Test //program without this keyword
        {
  int id; //instance variable
  String name;
  Test(int id,String name) //parameters inside the brase
  {
      id=id;
      name=name;
  }
  public void display(){
      System.out.println(id+" "+name);
  }

        public static void main(String[] args) {
            Test t=new Test(101,"sweety");
            Test t1=new Test(102,"vahini");
            t1.display();
            t.display();
        }
}

