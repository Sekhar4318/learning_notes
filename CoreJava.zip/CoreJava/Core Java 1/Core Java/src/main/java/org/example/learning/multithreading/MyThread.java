package org.example.learning.multithreading;
//Using the Thread Class: Thread(String Name)

public class MyThread {
    public static void main(String[] args) {
        // creating an object of the Thread class using the constructor Thread(String name)
        Thread t=new Thread("My first thread");
        // the start() method moves the thread to the active state
        t.start();
        t.setName("changing my first thraed");
        // getting the thread name by invoking the getName() method  
    String str=t.getName();
    System.out.println(str);
    }
}
