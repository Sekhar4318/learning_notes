package org.example.learning.loopstatments;

public class DoWhile {
    public static void main(String[] args) {
        int num=0;
        System.out.println("print first 10 even numbers");
        do
        {
            //num=num+2;
            System.out.println(num);
            num=num+2;
        }while(num<=10);
    }
}
