package org.example.learning.jumpstatements;

public class BreakStatement {
    public static void main(String[] args) {
        int i;
        for (i = 0; i < 8; i++) {
            System.out.println(i);
            if (i == 6) {
                break;
            }
        }
    }
}
