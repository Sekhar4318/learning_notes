package org.example.learning.loopstatments;

public class ForLoop {
    public static void main(String[] args) {
        int sum=0;
    for(int j=1;j<=10;j++){
        sum =sum+j;
       // System.out.println("first sum of natural num is"+sum);
    }
       System.out.println("first sum of natural num is"+sum);
    }
}
