package org.example.learning.execptionhandling;

public class FinallyBlockExp {
    public static void main(String[] args) {
        try{
            System.out.println("inside the try block");
            int data=25/0;
            System.out.println(data);
        }
        catch (NullPointerException e){
            System.out.println(e);
            System.out.println("inside catch block");
        }
//        catch (ArithmeticException e1){
//            System.out.println(e1);
//            System.out.println("inside catch2 block");
//        }
        finally {
            System.out.println("Final block always executed ");
            //final block always executed whether the exception handled or not it will executed
        }
    }
}
