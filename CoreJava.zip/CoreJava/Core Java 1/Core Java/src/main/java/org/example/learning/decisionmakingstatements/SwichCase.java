package org.example.learning.decisionmakingstatements;

public class SwichCase {
    public static void main(String[] args) {
        int num=6;
        switch (num){
            case 0:
                System.out.println("print 0");
                break;
            case 1:
                System.out.println("print 1");
                break;
            case 2:
                System.out.println("print 2");
                break;
            default:
                System.out.println(num);
        }
    }
}
