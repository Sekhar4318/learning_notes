package org.example.learning.aggregation;

public class Address {
    String city,country;

    public Address(String city, String country) {
        this.city = city;
        this.country = country;
    }
}

