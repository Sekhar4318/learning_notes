package org.example.learning.decisionmakingstatements;

public class IfStatement {
    public static void main(String[] args) {
        int a=10,b=12;
        if(a<b)
            System.out.println("true");
    }
}

