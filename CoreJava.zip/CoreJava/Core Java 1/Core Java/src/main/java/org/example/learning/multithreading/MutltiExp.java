package org.example.learning.multithreading;
//Java Thread Example by implementing Runnable interface
public class MutltiExp implements Runnable {
    public void run() {
        System.out.println("thraed run....");

    }

    public static void main(String[] args) {
        MutltiExp m=new MutltiExp();
        Thread t=new Thread(m);// Using the constructor Thread(Runnable r)
        t.start();
    }
}
