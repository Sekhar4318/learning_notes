package org.example.learning.statickeyword;

public class Student3 {
    static //static block executed before mainmethod
    {
        System.out.println("static block program");
    }

    public static void main(String[] args) {
        System.out.println("hello");
    }
}
