package org.example.learning.inheritance;

class Animal2{
    void eat(){
        System.out.println("eating...");
    }
}
class Dog2 extends Animal2{
    void barking(){
        System.out.println("BARKING....");
    }
}
class Cat extends Animal2{
    void meow(){
        System.out.println("sleeping....");
    }
}

public class HierarchialInheritance {
    public static void main(String[] args) {
       Cat c=new Cat();
       c.meow();
       c.eat();
    }
}
