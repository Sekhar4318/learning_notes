package org.example.learning.instanceofoperator;
 class Animal {
    void eat(){
        System.out.println("eating..");
    }
}
public class InstanceOfOpt{
    public static void main(String[] args) {
        Animal a=new Animal();
        a.eat();
        System.out.println(a instanceof Animal);//returns true
    }
}
