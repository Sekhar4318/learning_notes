package org.example.learning.loopstatments;

public class WhileLoop {
    public static void main(String[] args) {
        int num=0;
        System.out.println("print first 10 even numbers");
        while (num<=10)
        {
            //num=num+2;
            System.out.println(num);
            num=num+2;
        }
    }
}
