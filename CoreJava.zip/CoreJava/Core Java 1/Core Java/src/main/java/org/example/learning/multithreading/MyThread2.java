package org.example.learning.multithreading;
// Using the Thread Class: Thread(Runnable r, String name)

public class MyThread2 implements Runnable{
    public void run() {
        try {
            Thread.sleep(1000);
        }
        catch (InterruptedException e){
            System.out.println(e);
        }
        System.out.println("thraed running..."+Thread.currentThread().getPriority());

    }

    public static void main(String[] args) throws InterruptedException {
        Runnable r=new MyThread2();
        Thread t=new Thread(r,"hey running");
      //  Thread.sleep(1000);
        Thread t1=new Thread(r,"hey running");
        t.setPriority(10);
        t1.setPriority(5);
        t.start();
        t1.start();
        String str=t.getName();
        System.out.println(str);
    }
}
