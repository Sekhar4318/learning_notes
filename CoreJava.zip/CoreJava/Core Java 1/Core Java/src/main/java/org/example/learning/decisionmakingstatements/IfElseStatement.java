package org.example.learning.decisionmakingstatements;

public class IfElseStatement {
    public static void main(String[] args) {
        String city="Hyderabad";
        if(city=="delhi") {
            System.out.println("city hyderabad");
        }
            else {
                System.out.println("city is not a hyderabad");
            }
        }
    }

