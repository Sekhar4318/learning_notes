package org.example.learning.statickeyword;

public class Student2 {
    int id;
    String name;
    static String college="MLR";
    static void change(){ //Static block
        college="SVS";
    }
    Student2(int i,String n){
        id=i;
        name=n;

    }
    void display(){
        System.out.println(id+" "+name+" "+college);
    }

    public static void main(String[] args) {
        Student2 s1=new Student2(101,"sweety");
        Student2 s2=new Student2(102,"sony");
        System.out.println("Static method program...");
        Student2.change();
        s1.display();
        s2.display();

    }
}




