package org.example.learning.staticanddynamicbinding;
//Example of dynamic binding
class Animal1{
    void eat(){
        System.out.println("eating bread...");
    }
}
class Dog extends Animal1{
    void eat(){
        System.out.println("eating biccuit...");
    }
}
public class DynamicBinding {
    public static void main(String[] args) {
        Dog d=new Dog();
        d.eat();
    }

}
