package org.example.learning.jumpstatements;

public class ContinueStatement {
    public static void main(String[] args) {
        int i;
        for (i = 0; i < 8; i++) {
            if (i == 2) {
              continue;
            }
          System.out.println(i);
        }
    }
}

