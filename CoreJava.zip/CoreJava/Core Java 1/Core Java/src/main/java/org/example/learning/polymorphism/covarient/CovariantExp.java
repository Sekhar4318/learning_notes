package org.example.learning.polymorphism.covarient;

class A1{
    A1 foo(){
        return this;
    }
    void print(){
        System.out.println("inside A1");
    }
}
class A2 extends A1{
    A2 foo(){
        return this;
    }
    void print(){
        System.out.println("inside A2");
    }
}
class A3 extends A2{
    A3 foo(){
        return this;
    }
    void print(){
        System.out.println("inside A3");
    }
}

public class CovariantExp {
    public static void main(String[] args) {
        A3 a3=new A3();
        a3.foo().print();
        A2 a2=new A2();
        a2.foo().print();
        A1 a1=new A1();
        a1.foo().print();

    }
}
