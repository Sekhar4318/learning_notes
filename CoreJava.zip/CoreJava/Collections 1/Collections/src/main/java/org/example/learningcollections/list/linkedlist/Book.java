package org.example.learningcollections.list.linkedlist;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Book {
    private int id;
    private String name, author;
    private long price;

    public Book(int id,String name, String author, long price) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.price = price;
    }

    public static void main(String[] args) {
        List<Book> l=new LinkedList<Book>();
       Book b1=new Book(101,"Java","KVS",4000L);
        Book b2=new Book(102,"pthon","Sundaram",2000L);
        l.add(b1);
        l.add(b2);
        for (Book bl:l)
        {
            System.out.println(bl.id+" "+bl.name+" "+bl.author+" "+bl.price);
        }


    }
}
