package org.example.learningcollections.comparable;

import java.util.Arrays;

@
public class Student implements Comparable<Student> {
    int id;
     String name;
     int age;

    public Student(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    @Override
    public int compareTo(Student student) {
        if (age == student.age) {
            return 0;
        } else if (age < student.age) {
            return 1;
        } else {
            return -1;
        }


    }

    public static void findSmallestNumber(int[] arr){
         int secondLargestNum = Arrays.stream(arr).distinct().sorted().skip(1).findFirst().getAsInt();
         System.out.println(secondLargestNum);

    }
    public static void reverseArray(int[] arr){
        int length = arr.length;
        for (int i = 0 ; i<length/2; i++){
            int temp = arr[i];
            arr[i]= arr[length-1-i];
            arr[length-1-i] = temp;
        }

    }
    public static void largestChar(String[] arr){
        Arrays.stream(arr).mapToInt(String::length).max().orElse(0);

    }



    public static void main(String[] args){
        int [] arr = {5,6,3,7,1};
        findSmallestNumber(arr);
        reverseArray(arr);



    }
}

