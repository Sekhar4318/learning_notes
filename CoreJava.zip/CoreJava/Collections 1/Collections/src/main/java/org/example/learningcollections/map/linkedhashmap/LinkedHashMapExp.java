package org.example.learningcollections.map.linkedhashmap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapExp {
    public static void main(String[] args) {
        LinkedHashMap <Integer,String> m=new LinkedHashMap<>();
        m.put(12,"vahini");
        m.put(11,"sweety");
        m.put(12,"sony");
        m.put(14,"sharu");
        m.put(16,"vyshu");
        m.put(null,"hello");
        m.put(null,"hey");
        m.put(25,null);
        m.put(28,null);
        System.out.println("keys"+" "+m.keySet());
        System.out.println("values"+" "+m.values());
        for (Map.Entry map: m.entrySet()
        ) {
            System.out.println(map.getKey()+" "+map.getValue());
        }
    }
}

