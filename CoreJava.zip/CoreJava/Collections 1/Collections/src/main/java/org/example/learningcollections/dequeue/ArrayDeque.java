package org.example.learningcollections.dequeue;

import java.util.Queue;

public class ArrayDeque {
    public static void main(String[] args) {
        Queue<Integer> queue=new java.util.ArrayDeque<>();
        queue.add(5);
        queue.add(2);
        queue.add(1);
        queue.add(2);
        queue.add(22);
        queue.add(6);
        System.out.println("element"+queue.element());
        //queue.add(null);
        for (int ql:queue
             ) {
            System.out.println(ql);
        }
    }
}
