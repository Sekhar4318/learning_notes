package org.example.learningcollections.map.treemap;

import java.util.Map;
import java.util.TreeMap;

public class Book {
    private int id;
    private  String name ;
    private int quality;
    private double price;

    public Book(int id, String name, int quality, double price) {
        this.id = id;
        this.name = name;
        this.quality = quality;
        this.price = price;
    }

    public static void main(String[] args) {
        TreeMap<Integer,Book> map=new TreeMap<>();
        Book b1=new Book(12,"JAVA",1,500.20);
        Book b2=new Book(14,"PYTHON",3,200.20);
        Book b3=new Book(11,"C",2,300.20);
        Book b4=new Book(14,null,3,200.20);
        map.put(2,b1);
        map.put(1,b3);
        map.put(3,b2);
        map.put(3,b4);
        for (Map.Entry<Integer,Book> m:map.entrySet()
             ) {
            int key=m.getKey();
            Book b=m.getValue();
            System.out.println("DetailId"+" "+key);
            System.out.println(b.id+" "+b.name+" "+b.quality+" "+b.price);
        }

    }
}
