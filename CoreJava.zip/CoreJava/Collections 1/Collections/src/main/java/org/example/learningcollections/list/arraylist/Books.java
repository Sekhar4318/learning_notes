package org.example.learningcollections.list.arraylist;

import java.util.ArrayList;
import java.util.List;

public class Books {
    private int id;
    private String name, author;
    private long price;

    public Books(int id,String name, String author, long price) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.price = price;
    }

    public static void main(String[] args) {
        List <Books>l=new ArrayList<Books>();
        Books b1=new Books(101,"Java","KVS",4000L);
        Books b2=new Books(102,"pthon","Sundaram",2000L);
       l.add(b1);
       l.add(b2);
        for (Books bl:l)
              {
           System.out.println(bl.id+" "+bl.name+" "+bl.author+" "+bl.price);
        }


    }
}


