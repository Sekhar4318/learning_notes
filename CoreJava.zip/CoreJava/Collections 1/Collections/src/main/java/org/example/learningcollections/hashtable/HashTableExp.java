package org.example.learningcollections.hashtable;

import java.util.Hashtable;
import java.util.Map;

public class HashTableExp {
    public static void main(String[] args) {
        Hashtable<Integer,String> ht=new Hashtable<>();
        ht.put(8,"java");
        ht.put(5,"c");
        ht.put(4,"python");
        ht.put(2,"angular");
        //ht.put(6,null);
        //ht.put(null,"nsh");
        ht.put(2,"hsn");
        for (Map.Entry<Integer,String> m: ht.entrySet()
             ) {
            System.out.println(m.getKey()+" "+m.getValue());
        }
    }
}
