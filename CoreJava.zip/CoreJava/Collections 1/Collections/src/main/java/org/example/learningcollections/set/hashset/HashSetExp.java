package org.example.learningcollections.set.hashset;

import java.util.HashSet;
import java.util.Set;

public class HashSetExp {
    public static void main(String[] args) {
        Set<Integer> s=new HashSet<>();
        s.add(2);
        s.add(5);
        s.add(4);
        s.add(2);
        s.add(6);
       // s.add(null);
        for (int list:s
             ) {
            System.out.println(list);
        }
    }
}
