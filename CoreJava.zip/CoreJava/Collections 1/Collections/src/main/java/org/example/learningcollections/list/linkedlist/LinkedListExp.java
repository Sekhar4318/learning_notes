package org.example.learningcollections.list.linkedlist;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

public class LinkedListExp {
    public static void main(String[] args) {
        LinkedList<String> list=new LinkedList<>();
        list.add("vahini");
        list.add("sharath");
        list.add("sweety");
        list.add("shivanisharath");
        list.add("sharath");
      Collections.sort(list);
      Collections.reverse(list);
      list.remove("sweety");
        for (String names:list){
            System.out.println(names);
        }

    }
}
