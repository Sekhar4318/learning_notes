package org.example.learningcollections.enummap;


import java.util.EnumMap;
import java.util.Map;


    enum days{
        Monday,tuesday,wenesday,thursday,friday,saturday,sunday;
    }
    public class EnumMapExp {
        public static void main(String[] args) {
        EnumMap<days,Integer> map= new EnumMap<days,Integer>(days.class);
        map.put(days.Monday,2);
        map.put(days.saturday,1);
        map.put(days.sunday,5);
            for (Map.Entry<days,Integer> m:map.entrySet()
                 ) {
                System.out.println(m.getKey()+" "+m.getValue());
            }

    }
}
