package org.example.learningcollections.comparator;

import java.util.ArrayList;
import java.util.Collections;

public class Test {
    public static void main(String[] args) {
        ArrayList<Student> al=new ArrayList<>();
        al.add(new Student(1,"vahini",21));
        al.add(new Student(2,"sony",22));
        al.add(new Student(3,"vahini",24));
        System.out.println("sorting by name");
        Collections.sort(al,new NameComparator());
        for (Student st1:al
             ) {
            System.out.println(st1.id+" "+st1.name+" "+ st1.age);
        }
        System.out.println("sorting by age");
        Collections.sort(al,new AgeComparator());
        for (Student st2:al
        ) {
            System.out.println(st2.id+" "+st2.name+" "+ st2.age);
        }

    }
}
