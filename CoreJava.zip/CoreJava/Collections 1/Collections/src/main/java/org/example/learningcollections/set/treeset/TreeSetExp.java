package org.example.learningcollections.set.treeset;

import java.util.TreeSet;

public class TreeSetExp {
    public static void main(String[] args) {
        TreeSet<Integer> ts=new TreeSet<>();
        ts.add(5);
        ts.add(2);
        ts.add(4);
        ts.add(4);
        ts.add(1);
       // ts.add(null);
        for (int treeset:ts
             ) {
            System.out.println(treeset);
        }
    }
}
