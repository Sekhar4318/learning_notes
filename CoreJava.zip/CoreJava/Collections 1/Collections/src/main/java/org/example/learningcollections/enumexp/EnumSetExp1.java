package org.example.learningcollections.enumexp;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;

enum days{
    Monday,Tuesday,wenesday,thursday,friday,saturday,sunday;
}

public class EnumSetExp1 {
    public static void main(String[] args) {
        Set<days> set = EnumSet.of(days.Monday, days.friday);
        Iterator<days> itr= set.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }

    }
}
