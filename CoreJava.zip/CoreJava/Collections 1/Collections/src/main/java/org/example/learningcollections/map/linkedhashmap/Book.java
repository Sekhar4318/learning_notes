package org.example.learningcollections.map.linkedhashmap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public class Book {
    private int id;
    private String name,author;
    private double cost;

    public Book(int id, String name, String author, double cost) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.cost = cost;
    }

    public static void main(String[] args) {
        LinkedHashMap<Integer, Book> map=new LinkedHashMap<>();
       Book b1=new Book(10,"C","KVS",500.50);
       Book b4=new Book(14,"PYTHON","VS",700.50);
       Book b2=new Book(12,"JAVA","VS",700.50);
        Book b3=new Book(14,"PYTHON","VS",700.50);
        map.put(1,b1);
        map.put(2,b2);
        map.put(5,b2);
        map.put(2,b3);
        map.put(4,b4);
        for (Map.Entry<Integer, Book> entry:map.entrySet()
        ) {
            int key= entry.getKey();
           Book b= entry.getValue();
            System.out.println("DETAIL ID"+" "+key);
            System.out.println(b.id+" "+b.name+" "+b.author+" "+b.author);

        }
    }
}

