package org.example.learningcollections.enumexp;

import java.util.EnumSet;
import java.util.Set;

enum day{
    Monday,Tuesday,wenesday,thursday,friday,saturday,sunday;
}
public class EnumSetExp2 {
    public static void main(String[] args) {
        Set<day> set1= EnumSet.allOf(day.class);
        Set<day> set2=EnumSet.noneOf(day.class);
        System.out.println("Set1"+set1);
        System.out.println("Set2"+set2);

    }
}
