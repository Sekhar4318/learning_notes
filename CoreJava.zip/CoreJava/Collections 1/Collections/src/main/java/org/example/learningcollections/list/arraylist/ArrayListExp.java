package org.example.learningcollections.list.arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExp {
    public static void main(String[] args) {
        ArrayList<Integer> list=new ArrayList<>();
        list.add(20);
        list.add(12);
        list.add(24);
        list.add(20);
        list.add(null);
        Iterator itr= list.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }
    }
}
