package org.example.learningcollections.map.hashmap;

import java.util.HashMap;
import java.util.Map;

public class HashMapExp {
    public static void main(String[] args) {
        HashMap<Integer,String> m=new HashMap<>();
        m.put(12,"vahini");
        m.put(11,"sweety");
        m.put(12,"sony");
        m.put(14,"sharu");
        m.put(16,"vyshu");
        m.put(null,"hello");
        m.put(null,"hey");
        m.put(25,null);
        m.put(28,null);
        for (Map.Entry map: m.entrySet()
        ) {
            System.out.println(map.getKey()+" "+map.getValue());
        }
    }
}

