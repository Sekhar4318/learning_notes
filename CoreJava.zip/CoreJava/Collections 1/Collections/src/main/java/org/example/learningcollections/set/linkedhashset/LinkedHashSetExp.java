package org.example.learningcollections.set.linkedhashset;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetExp {
    public static void main(String[] args) {
        Set<Integer> set=new LinkedHashSet<>();
        set.add(5);
        set.add(2);
        set.add(5);
        set.add(3);
        set.add(null);
        set.remove(null);
        for (int s:set
             ) {
            System.out.println(s);
        }

    }
}
