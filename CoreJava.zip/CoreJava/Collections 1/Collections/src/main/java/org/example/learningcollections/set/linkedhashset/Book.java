package org.example.learningcollections.set.linkedhashset;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

public class Book {
    private int id;
    private String name, author;
    private long price;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return id == book.id && price == book.price && Objects.equals(name, book.name) && Objects.equals(author, book.author);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, author, price);
    }

    public Book(int id, String name, String author, long price) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.price = price;
    }

    public static void main(String[] args) {
        Set <Book>set=new LinkedHashSet<>();
       Book b1=new Book(100,"Java","KVS",4000L);
        Book b2=new Book(102,"pthon","Sundaram",2000L);
        Book b3=new Book(100,"Java","VVS",3000L);
        Book b4=new Book(100,"Java","VVS",3000L);
        set.add(b1);
        set.add(b2);
        set.add(b3);
        set.add(b4);
        for (Book bl:set)
        {
            System.out.println(bl.id+" "+bl.name+" "+bl.author+" "+bl.price);
        }


    }
}
