package org.example.learningcollections.enummap;

import java.util.EnumMap;
import java.util.Hashtable;
import java.util.Map;

public class Book {
    private int id;
    private String name,author;
    private double cost;

    public Book(int id, String name, String author, double cost) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.cost = cost;
    }
    enum key{
        one,two,three,four;
    }

    public static void main(String[] args) {
        EnumMap<key,Book> map=new EnumMap<>(key.class);
       Book b1=new Book(10,"C","KVS",500.50);
        Book b4=new Book(14,"PYTHON","VS",700.50);
        Book b2=new Book(12,"JAVA","VS",700.50);
        Book b3=new Book(14,"PYTHON","VS",700.50);
        map.put(key.two,b1);
        map.put(key.one,b2);
        map.put(key.three,b2);
        map.put(key.four,b3);
        map.put(key.one,b4);
        for (Map.Entry<key,Book> entry:map.entrySet()
        ) {
           Book b= entry.getValue();
            System.out.println("DETAIL ID"+" "+entry.getKey());
            System.out.println(b.id+" "+b.name+" "+b.author+" "+b.author);

        }
    }
}

