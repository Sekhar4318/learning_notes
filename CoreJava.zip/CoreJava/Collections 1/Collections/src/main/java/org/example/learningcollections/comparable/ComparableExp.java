package org.example.learningcollections.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableExp {
    public static void main(String[] args) {
        ArrayList<Student> list = new ArrayList<>();
        list.add(new Student(1, "vahini", 23));
        list.add(new Student(2, "sweety", 22));
        list.add(new Student(3, "sony", 21));
        Collections.sort(list);
        for (Student st : list
        ) {
            System.out.println(st.id+" "+st.name+" "+ st.age);
        }
    }
}

