package org.example.learningcollections.map;

import java.util.HashMap;
import java.util.Map;

public class MapExp
{
    public static void main(String[] args) {
        Map<Integer,String> m=new HashMap<>();
        m.put(12,"vahini");
        m.put(11,"sweety");
        m.put(12,"sony");
        m.put(14,"sharu");
        m.put(16,"vyshu");
        for (Map.Entry map: m.entrySet()
             ) {
            System.out.println(map.getKey()+" "+map.getValue());
        }
    }
}
