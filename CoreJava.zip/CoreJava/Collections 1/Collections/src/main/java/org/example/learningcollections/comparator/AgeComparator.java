package org.example.learningcollections.comparator;

import java.util.Comparator;

public class AgeComparator implements Comparator<org.example.learningcollections.comparator.Student> {


    @Override
    public int compare(Student s1, Student s2) {
        if(s1.id==s2.id){
            return 0;

    } else if (s1.id<s2.id) {
            return 1;

        }
        else {
            return -1;
        }
    }


}
