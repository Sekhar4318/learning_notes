package org.example.learningcollections.queue;

import java.util.Collection;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExp {
    public static void main(String[] args) {
        Queue<Integer> queue = new PriorityQueue<>();
        {
            queue.offer(20);
            queue.add(6);
            queue.add(4);
            queue.add(2);
            queue.add(20);
            queue.add(3);
            //queue.add(null);
           System.out.println("peek element"+" :"+queue.peek());
            System.out.println("poll element"+" :"+queue.poll());
            for (int q : queue
            ) {
                System.out.println(q);
            }

        }
    }
}