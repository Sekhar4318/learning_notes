package com.dmbackend.accountDetailsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountDetailsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
