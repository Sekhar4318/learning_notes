package com.dmbackend.accountDetailsService.controller;


import com.dmbackend.accountDetailsService.model.AccountDetails;
import com.dmbackend.accountDetailsService.service.AccountDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@RestController
public class AccountDetailsController {

    @Autowired
    private AccountDetailsService service;

//    @PreAuthorize("hasRole('User')")
    @GetMapping("/myAccount-details/{userName}")
    public AccountDetails getAccountDetails(@PathVariable(name="userName") String userName){
        System.out.println("AccountDetails-Controller");
        return service.getUserAccountDetails(userName);
    }

    @PutMapping("/myAccount-details/update")
    public ResponseEntity<String> updateUserAccountDetails(@RequestBody AccountDetails accountDetails){
        service.updateUserAccountDetails(accountDetails);

        System.out.println("Inside update account Details method");
        return new ResponseEntity<>(HttpStatus.valueOf(204));
    }


}
