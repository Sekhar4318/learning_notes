package com.dmbackend.accountDetailsService.service;


import com.dmbackend.accountDetailsService.model.AccountDetails;
import com.dmbackend.accountDetailsService.repository.AccountDetailsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

@Service
public class AccountDetailsService {

//    @Autowired
//    private LocationService locationService;
    @Autowired
    private AccountDetailsRepo repo;


    @Autowired
    private RestTemplate restTemplate;

//    @Autowired
//    private UserRepository userRepository;

    public AccountDetailsService(AccountDetailsRepo accountDetailsRepo, RestTemplate restTemplate) {
        this.repo = accountDetailsRepo;
        this.restTemplate = restTemplate;
    }

    public AccountDetails getUserAccountDetails(String userName){
        AccountDetails accountDetails = repo.getAccountDetailsByUserName(userName);
        return accountDetails;
    }

//    public void saveUserAccountDetails(AccountDetails accountDetails){
//        repo.save(accountDetails);
//    }


    @Transactional
    public void updateUserAccountDetails(AccountDetails accountDetails){
//        restTemplate.put("http://localhost:8083/myAccount-details/update-location", accountDetails.getLocation());
//        locationService.saveLocation(accountDetails.getLocation());
        repo.save(accountDetails);
    }
}
