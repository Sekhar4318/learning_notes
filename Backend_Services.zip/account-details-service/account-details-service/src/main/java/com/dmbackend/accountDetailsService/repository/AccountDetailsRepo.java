package com.dmbackend.accountDetailsService.repository;


import com.dmbackend.accountDetailsService.model.AccountDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountDetailsRepo extends JpaRepository<AccountDetails, Integer> {
    @Query(value = "SELECT * FROM account_details ad LEFT JOIN location lc ON ad.location_location_id = lc.location_id  WHERE ad.user_name = :userName", nativeQuery = true)
    AccountDetails getAccountDetailsByUserName(@Param("userName") String userName);

//    @Query(value = "SELECT account_details.*, location.location_id AS location_location_id, location.other_column AS location_other_column " +
//            "FROM account_details " +
//            "JOIN location ON account_details.location_id = location.location_id " +
//            "WHERE account_details.user_name = :userName", nativeQuery = true)
//    AccountDetails getAccountDetailsByUserName(@Param("userName") String userName);

}
