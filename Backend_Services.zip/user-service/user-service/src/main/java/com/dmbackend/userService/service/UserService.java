package com.dmbackend.userService.service;


import com.dmbackend.userService.model.Role;
import com.dmbackend.userService.model.User;
import com.dmbackend.userService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashSet;
import java.util.Set;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

//    @Autowired
//    private RoleRepository roleRepository;


    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, RestTemplate restTemplate, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.restTemplate = restTemplate;
        this.passwordEncoder = passwordEncoder;
    }

//    public UserService(RestTemplate restTemplate) {
//        this.restTemplate = restTemplate;;
//    }

    public void initRoleAndUser() {

        Role adminRole = new Role();
        adminRole.setRoleName("Admin");
        adminRole.setRoleDescription("Admin role");
        String url = "http://localhost:8085/createNewRole";
        restTemplate.postForObject(url, adminRole, Role.class);
//        roleRepository.save(adminRole);

        Role userRole = new Role();
        userRole.setRoleName("User");
        userRole.setRoleDescription("Default role for newly created record");
        restTemplate.postForEntity(url, userRole, String.class);

//        roleRepository.save(userRole);

        User adminUser = new User();
        adminUser.setUserName("sekhar@admin");
        adminUser.setUserPassword(getEncodedPassword("sekhar4318"));
        adminUser.setUserFirstName("sekhar");
        adminUser.setUserLastName("kummari");
        Set<Role> adminRoles = new HashSet<>();
        adminRoles.add(adminRole);
        adminUser.setRole(adminRoles);
        userRepository.save(adminUser);

    }



    public User registerNewUser(User user) {
        String url = "http://role-service/userRole/User";
        Role role = restTemplate.getForEntity(url, Role.class).getBody();
//        Role role = roleRepository.findById("User").get();
        Set<Role> userRoles = new HashSet<>();
        userRoles.add(role);
        user.setRole(userRoles);
        user.setUserPassword(getEncodedPassword(user.getUserPassword()));

        return userRepository.save(user);
    }

    public String getEncodedPassword(String password) {
        return passwordEncoder.encode(password);
    }

    public User findUserByUserName(String userName){
       return userRepository.findById(userName).orElseThrow();
    }
}
