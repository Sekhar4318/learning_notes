package com.dmbackend.locationService.service;

import com.dmbackend.locationService.model.Location;
import com.dmbackend.locationService.repository.LocationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LocationService {


    @Autowired
    private LocationRepo locationRepo;


    public void saveLocation(Location location){
        locationRepo.save(location);
    }

//
    public Location updateLocation(Location location) throws Exception {
        if (location != null) {
            Optional<Location> optDbLocation = locationRepo.findById(location.getLocationId());
            if (optDbLocation.isPresent()) {
                Location dbLocation = optDbLocation.get();
                dbLocation.setAddressLine1(location.getAddressLine1());
                dbLocation.setAddressLine2(location.getAddressLine2());
                dbLocation.setCity(location.getCity());
                dbLocation.setState(location.getState());
                dbLocation.setZipCode(location.getZipCode());
                saveLocation(dbLocation);

            } else throw new Exception("Location data not found in DB");

        } else throw new Exception("entered location is empty");
        return location;
    }
    }
