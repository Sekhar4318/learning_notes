package com.dmbackend.locationService.controller;

import com.dmbackend.locationService.model.AccountDetails;
import com.dmbackend.locationService.model.Location;
import com.dmbackend.locationService.repository.LocationRepo;
import com.dmbackend.locationService.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;


@Controller
public class LocationController {

    @Autowired
    private LocationService locationService;


    @Autowired
    private LocationRepo locationRepo;


    @Autowired
    private RestTemplate restTemplate;


//    @Autowired
//    private AccountDetailsService accountDetailsService;


    @Transactional
    @PostMapping("/myAccount-details/save-location/{userName}")
    public ResponseEntity<String> saveLocation(@RequestBody Location location, @PathVariable("userName") String userName) throws Exception {
        System.out.println("Location Controller inside Save location method");
        String url = "http://account-details-service/myAccount-details/sekhar.kummari";
        AccountDetails accountDetails = restTemplate.getForEntity(url, AccountDetails.class).getBody();
//        AccountDetails accountDetails = accountDetailsService.getUserAccountDetails(userName);
        locationService.updateLocation(location);
        accountDetails.setLocation(location);

        restTemplate.put("http://account-details-service/myAccount-details/update", accountDetails);
//        accountDetailsService.saveUserAccountDetails(accountDetails);
       return new ResponseEntity<>("User location saved successfuly",HttpStatus.CREATED);

    }

    @PutMapping("/myAccount-details/update-location")
    public ResponseEntity<Location> updateUserLocation(@RequestBody Location location) throws Exception {
        Location updatedLocation = locationService.updateLocation(location);
        return new ResponseEntity<>(location, HttpStatus.CREATED);
    }

//    @PostMapping("/myAccount-details/")
//    public ResponseEntity<String> saveLocationData(@RequestBody Location location){
//
//    }


}
