package com.dmbackend.locationService.repository;

import com.dmbackend.locationService.model.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LocationRepo extends JpaRepository<Location, Integer> {

//    @Query(value = "update location set ")
//    void updateLocationById(Location location, Integer locationId);
}
