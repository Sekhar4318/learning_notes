package com.dmbackend.roleService.service;


import com.dmbackend.roleService.model.Role;
import com.dmbackend.roleService.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    public Role createNewRole(Role role) {
        return roleRepository.save(role);
    }

    public Role findByRoleName(String roleName) {
        Optional<Role> role = roleRepository.findById(roleName);
        return role.get();
    }
}
