package com.dmbackend.roleService.controller;


import com.dmbackend.roleService.model.Role;
import com.dmbackend.roleService.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class RoleController {

    @Autowired
    private RoleService roleService;

    @PostMapping("/createNewRole")
    public Role createNewRole(@RequestBody Role role) {
        return roleService.createNewRole(role);
    }

    @GetMapping("/userRole/{roleName}")
    public Role findByRoleName(@PathVariable String roleName){
        return roleService.findByRoleName(roleName);
    }
}
