package com.dmbackend.productservice.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table
@NoArgsConstructor
public class Cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cartId;
	@OneToOne
	private Product product;
	@OneToOne
	private User user;

	public Cart(Product product, User user) {
		this.product = product;
		this.user = user;
	}
}
