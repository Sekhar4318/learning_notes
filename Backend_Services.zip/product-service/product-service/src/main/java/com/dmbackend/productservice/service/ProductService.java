package com.dmbackend.productservice.service;
import com.dmbackend.productservice.model.Product;
import com.dmbackend.productservice.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
//	@Autowired
////	private UserRepository userRepository;
////	@Autowired
////	private CartRepository cartRepository;

	public ProductService(ProductRepository productRepository){
		this.productRepository = productRepository;
	}
	
	public Product addNewProduct(Product product) {
		return productRepository.save(product);
	}
	
	public List<Product> getAllProducts(int pageNumber, String searchKey){
		Pageable pageable = PageRequest.of(pageNumber, 8);
		
		if(searchKey.equals("")) {
			return productRepository.findAll(pageable);
		}else {
			return productRepository.findByProductNameContainingIgnoreCaseOrProductDescriptionContainingIgnoreCase(searchKey, searchKey, pageable);
		}
		
	}
	
	public void deleteProductDetails(Integer productId) {
		productRepository.deleteById(productId);
	}

	public Optional<Product> getProductDetailsById(Integer productId) {
		
		return productRepository.findById(productId);
	}
	
	public List<Product> getProductDetails(boolean isSingeProductCheckout, Integer productId) {
	
		if(isSingeProductCheckout && productId != 0) {
			List<Product> list= new ArrayList<>();
			Product product = productRepository.findById(productId).get();
			list.add(product);
			return list;
		}else {
		
//			String username = JwtRequestFilter.CURRENT_USER;
//			User user = userRepository.findById(username).get();
//			List<Cart>  carts= cartRepository.findByUser(user);
			
//			return carts.stream().map(x -> x.getProduct()).collect(Collectors.toList());
			
		}


		return null;
	}
	
	
	

}
