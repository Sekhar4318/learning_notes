package com.app.poc.designPatterns.factotyMethodPattern;

public class DesingPatterns {




}
