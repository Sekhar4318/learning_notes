package com.app.poc;

import java.io.IOException;

public class A {

//    public void m1() throws IOException {
//        System.out.println("parent m1 method");
//    }
//
//    public int parent() throws ArithmeticException {
//        System.out.println("Parent");
//        return 0;
//    }

    {
        System.out.println(1);
    }
}
