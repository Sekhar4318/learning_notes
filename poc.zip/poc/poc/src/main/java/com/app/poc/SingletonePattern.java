package com.app.poc;

public class SingletonePattern {

}
