package com.app.poc.designPatterns.factotyMethodPattern;

import com.app.poc.Plan;

public class CommercialPlan extends Plan {
    @Override
    public void getRate() {
        rate = 5.5;
    }
}
