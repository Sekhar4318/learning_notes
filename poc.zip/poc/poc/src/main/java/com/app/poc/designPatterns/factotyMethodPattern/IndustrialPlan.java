package com.app.poc.designPatterns.factotyMethodPattern;

import com.app.poc.Plan;

public class IndustrialPlan extends Plan {
    @Override
    public void getRate() {
        rate=7.5;
    }
}
