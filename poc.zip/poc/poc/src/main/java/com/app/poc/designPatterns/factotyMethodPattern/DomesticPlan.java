package com.app.poc.designPatterns.factotyMethodPattern;

import com.app.poc.Plan;

public class DomesticPlan extends Plan {
    @Override
    public void getRate() {
        rate = 3.5;
    }
}
