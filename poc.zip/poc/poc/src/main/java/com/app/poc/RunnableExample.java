package com.app.poc;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RunnableExample implements Runnable{
    @Override
    public void run() {
        System.out.println("Runnable thread is running");



    }


}
