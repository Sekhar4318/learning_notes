package com.app.poc;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Problems {


    public static void main(String[] args){

//        listOfIntegers.stream().filter( num -> num% 5 == 0).forEach(System.out::println);





        //Prefix as [ and suffix as ] separated with delimiter ,
        List<String> listOfStrings = Arrays.asList("Facebook", "Twitter", "YouTube", "WhatsApp", "LinkedIn");
        String joinedString = listOfStrings.stream().collect(Collectors.joining(", ", "[", "]"));
        System.out.println(joinedString);
//        listOfStrings.stream().map( str -> "["+str+"]" + ",").forEach(System.out::println);


        //Frequency of each character
        System.out.println("Frequency of each character");
        String inputString = "Java Concept Of The Day";
        Map<Character, Long> charMap = inputString.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        inputString.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

        charMap.entrySet().stream().forEach(entrySet -> System.out.println(entrySet.getKey() + ":"+ entrySet.getValue()));


        List<Integer> numList = Arrays.asList(1,3,2,7,6,9,5,8,3,1);

//        int a = 10;
//        int b = 0;
//        int i = a / b;
//        HashSet<Integer> duplicateNum


//        numList.stream().filter(num -> num % 2 == 0 );

        HashMap<String, List<Integer>> hashMap = new HashMap<>();

        hashMap.put("list", numList);
        List<Integer> evenNum = new ArrayList<>();
        List<Integer> oddNum = new ArrayList<>();
        hashMap.entrySet().stream().map(entry -> entry.getValue().stream().filter(num -> num%2 == 0)).collect(Collectors.toList());

        hashMap.entrySet().stream().map(entry -> entry.getValue().stream().map(value -> value % 2 == 0 ? evenNum.add(value) : oddNum.add(value)).collect(Collectors.toList())).collect(Collectors.toList());

        System.out.println("Even Numbers");
        evenNum.stream().forEach(System.out::println);
        System.out.println("Odd Numbers");
        oddNum.stream().forEach(System.out::println);







        //Find all integers starting with 1
        System.out.println("Find all integers starting with 1");
        List<Integer> myList = Arrays.asList(10,15,8,49,25,98,32);
        myList.stream().filter( num -> num.toString().startsWith("1")).forEach(System.out::println);


        //Find duplicates in list of integer
        System.out.println("Find duplicates in list of integer");
        List<Integer> intList = Arrays.asList(10,15,8,49,25,98,98,32,15);
        Set<Integer> set = new HashSet<>();
        intList.stream().filter(num -> !set.add(num)).forEach(System.out::println);


        //Max
        System.out.println("-----------Max-------------");
        List<Integer> myList1 = Arrays.asList(10,15,8,49,25,98,98,32,15);
        int max =  myList1.stream()
                .max(Integer::compareTo)
                .get();
        System.out.println(max);


        //find the first non-repeated character
        System.out.println("-----------find the first non-repeated character-------------");
        String input = "Java articles are Awesome";
        HashMap<String,String> stringHashMap = new HashMap<>();

//        Map<Character, Long> map =  input.chars().mapToObj(s-> Character.toLowerCase ((char) s)).collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));
//
//        System.out.println(map.entrySet().stream().filter(key -> key.getValue() == 1).map(Map.Entry::getKey).findFirst().get());

        System.out.println(input.chars().mapToObj(s -> Character.toUpperCase((char) s)).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new, Collectors.counting())).entrySet().stream().filter(entry -> entry.getValue() == 1).map(s -> s.getKey()).findFirst().get());


        //Concatnate two streams
        System.out.println("Concatnate two streams");
        List<String> list1 = Arrays.asList("Java", "8");
        List<String> list2 = Arrays.asList("explained", "through", "programs");

        Stream<String> concatStream = Stream.concat(list1.stream(), list2.stream());

        // Concatenated the list1 and list2 by converting them into Stream

        concatStream.forEach(System.out::print);



        // Map & flat Map

        System.out.println("Map & flat Map");
        // List of names
        List<String> names = Arrays.asList("Alice", "Bob", "Charlie Brown");

        // map: Create a list of usernames with "user_" prefix
        List<String> usernames = names.stream()
                .map(name -> "user_" + name)
                .collect(Collectors.toList());

        List<List<String>> families = Arrays.asList(
                Arrays.asList("Alice", "Bob"),
                Arrays.asList("Charlie", "Snoopy")
        );

        List<String> allMembers = families.stream()
                .flatMap(Collection::stream)// Flatten each family list
                .collect(Collectors.toList());

        System.out.println(allMembers);



        //Each word length
        System.out.println("Word Length");

        List<String> namesList = Arrays.asList("AA", "BB", "AA", "CC");
        namesList.stream().map(word -> word.length()).forEach(System.out::print);


        //count of each character in a String?
        System.out.println("Word Length");
        String s = "string data to count each character";

        Arrays.stream(s.split("")).collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting())).entrySet().stream().forEach(System.out::println);


//        CartService cartService = new CartService();
//        cartService.jsonParser();



        //Find even numbers from ArrayList and find the sum of all numbers
        System.out.println("Find even numbers from ArrayList and find the sum of all numbers");
        List<Integer> numberList = Arrays.asList(1,4,3,5,6,8,9,7);
        System.out.println(numberList.stream().filter(num -> num % 2 == 0).mapToInt(Integer::intValue).sum());


    }
}
