package com.app.poc;

public class Multi  implements Runnable{

    public void run(){
        System.out.println("thread is running");
    }
}
