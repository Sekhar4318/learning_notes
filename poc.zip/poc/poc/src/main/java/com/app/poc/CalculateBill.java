package com.app.poc;

import java.io.IOException;
import java.util.Scanner;

public class CalculateBill {

//    public static void main(String args[]) throws IOException {
//        GetPlanFactory planFactory = new GetPlanFactory();
//        System.out.println("Enter Plan Name");
//        Plan plan =  planFactory.getPlan(String.valueOf(System.in.read()));
//        System.out.println("Enter Units to calculate the bill");
//        plan.calculateBill(System.in.read());
//
//    }


}
