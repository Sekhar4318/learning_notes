package com.app.poc;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ThreadClass extends Thread{

    public void run(){
        System.out.println("Thread is running.....");

    }


    List<Integer> listOfIntegers = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);


}
