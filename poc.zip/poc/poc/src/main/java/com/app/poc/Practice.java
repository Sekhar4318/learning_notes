package com.app.poc;

import javax.sound.midi.SysexMessage;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Practice {


    public static void main(String args[]){


        //Frequency of each character
        System.out.println("Frequency of each character");
        String inputString = "Java Concept Of The Day";


       Map<Character, Long> strMap =  inputString.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

       strMap.entrySet().stream().forEach(data -> System.out.println(data.getKey()));

        //Find duplicates in list of integer
        System.out.println("Find duplicates in list of integer");
        List<Integer> intList = Arrays.asList(10,15,8,49,25,98,98,32,15);
        Set<Integer> set = new HashSet<>();
        intList.stream().filter(num -> !set.add(num)).forEach(num -> System.out.println(num));

        intList.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));


        //Max
        System.out.println("-----------Max-------------");
        List<Integer> myList1 = Arrays.asList(10,15,8,49,25,98,98,32,15);


        int maxNum = myList1.stream().max(Integer::compareTo).get();


        //find the first non-repeated character
        System.out.println("-----------find the first non-repeated character-------------");
        String input = "Java articles are Awesome";


        Map<Character, Long> map = input.chars().mapToObj( c -> (char) c).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new, Collectors.counting()));

        map.entrySet().stream().filter(entryset -> entryset.getValue() == 1).map(s -> s.getKey()).findFirst().get();


        //Each word length
        System.out.println("Word Length");

        List<String> namesList = Arrays.asList("AA", "BB", "AA", "CC");


        namesList.stream().map(word ->word.length()).forEach(System.out::println);


        //Find even numbers from ArrayList and find the sum of all numbers
        System.out.println("Find even numbers from ArrayList and find the sum of all numbers");
        List<Integer> numberList = Arrays.asList(1,4,3,5,6,8,9,7);

        numberList.stream().filter(num -> num%2 == 0).mapToInt(Integer::intValue).sum();
    }
}
