package com.app.poc;

import java.io.IOException;

public class B extends A{

//    @Override
//    public void m1() throws IOException {
//        System.out.println("child m1 method");
//    }
//
//    public int child() throws Exception{
//        System.out.println("child");
//        return 0;
//    }

    {
        System.out.println(2);
    }

    public static void main(String[] args){
        B b = new B();
    }
}
