package com.app.poc.designPatterns.singletonePattern;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@AllArgsConstructor
@Setter
@Getter
public class Employee {

    private int empId;
    private String empName;
    private int empAge;

    //Early Instantiation
    private static Employee employee = new Employee();

    private Employee(){

    }

    private static Employee getEmployee(){
        return employee;
    }

    //Lazy Instantiation
    private static Employee emp;

    private static Employee getEmp(){
        if(emp == null){
            synchronized (Employee.class) {
                if(emp == null) {
                    emp = new Employee();
                }
            }
        }
        return emp;
    }

}
